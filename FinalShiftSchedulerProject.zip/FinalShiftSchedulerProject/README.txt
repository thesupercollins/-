
FINAL IOS PROJECT PACKAGE

Features:
- Shift Scheduler
- Offline support
- No ads
- SwiftUI interface
- Settings and statistics

Build on Windows:
1. Install AltStore
2. Upload project to Codemagic
3. Build IPA
4. Install on iPhone
